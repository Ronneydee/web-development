// JavaScript code

// iPhone products data (replace with your actual data)
const iphoneProducts = [
    { name: 'iPhone 12 Pro', brand: 'Apple', price: 999 },
    { name: 'iPhone 11', brand: 'Apple', price: 699 },
    { name: 'iPhone SE', brand: 'Apple', price: 399 },
    // Add more iPhone products as needed
  ];
  
  // Function to display the iPhone products
  function displayProducts(products) {
    const productsContainer = document.getElementById('products-container');
    productsContainer.innerHTML = '';
  
    products.forEach(product => {
      const productCard = document.createElement('div');
      productCard.classList.add('product-card');
  
      const productName = document.createElement('h3');
      productName.textContent = product.name;
  
      const productBrand = document.createElement('p');
      productBrand.textContent = `Brand: ${product.brand}`;
  
      const productPrice = document.createElement('p');
      productPrice.textContent = `Price: $${product.price}`;
  
      productCard.appendChild(productName);
      productCard.appendChild(productBrand);
      productCard.appendChild(productPrice);
  
      productsContainer.appendChild(productCard);
    });
  }
  
  // Initial display of all iPhone products
  displayProducts(iphoneProducts);
  
  // Function to filter iPhone products by brand
  function filterByBrand(brand) {
    const filteredProducts = iphoneProducts.filter(product => product.brand === brand);
    displayProducts(filteredProducts);
  }
  
  // Function to sort iPhone products by price (ascending or descending)
  function sortByPrice(order) {
    const sortedProducts = [...iphoneProducts];
    sortedProducts.sort((a, b) => {
      if (order === 'asc') {
        return a.price - b.price;
      } else if (order === 'desc') {
        return b.price - a.price;
      }
    });
    displayProducts(sortedProducts);
  }
  
  // Get the filter and sort buttons
  const filterButtons = document.querySelectorAll('.filter-button');
  const sortButtons = document.querySelectorAll('.sort-button');
  
  // Attach event listeners to each filter button
  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const brand = button.dataset.brand;
      filterByBrand(brand);
    });
  });
  
  // Attach event listeners to each sort button
  sortButtons.forEach(button => {
    button.addEventListener('click', () => {
      const order = button.dataset.order;
      sortByPrice(order);
    });
  });
  